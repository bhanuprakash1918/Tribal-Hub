import React from 'react'
import "./Home.css";
import bg from './bg.PNG';
import Product from "./Product";
function Home() {
    return (
        <div className='home'>
            <div className="home__container">
            <img 
            className="home__image" 
            src={bg} alt="bg" />

            <div className="home__row">
                {/*Product*/}
                
                {/*Product*/}
    
                
                <Product id="1" title='Tribal Decorative Showpiece - 28 cm  (Fabric, Multicolor) ; Orgin- Tribes Maharashtra' price={800} image="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTOFEKpDmt8zYupXrGJ_t0L5Z6xdnREPFBI9laFgRPjh06-Te_UwJjNUIumpmEZKa6wHTbuhYcUiIr4PyGzNm8k144JgNsoqs_RkwA15fFVwWn8dphu4CYG&usqp=CAE" rating={4}/>

                <Product id="2" title='Handmade Decorative Showpiece ; Orgin- Tribes New Delhi' price={430} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1SGADCTRJ01691_2_IMAGE_1-300x300.jpg" rating={3}/>
                
                
                
            

            </div>

            <div className="home__row">
                {/*Product*/}
            
                {/*Product*/}
                {/*Product*/}
            
                <Product id="3" title='Warli Cloth Painting ; Orgin- Tribes New Delhi' price={774} image="https://www.tribesindia.org/wp-content/uploads/2021/09/DSC_8415-300x300.jpg" rating={4}/>
                
                <Product id="4" title='Authentic Dhokra Art Metal Crafted Coconut Box ; Orgin- Tribes Assam' price={390} image="https://www.tribesindia.org/wp-content/uploads/2021/09/DSC_7025-300x300.jpg" rating={5}/>
                <Product id="5" title='Handcrafted Grey Metal Karela Bangle/Bracelet Pair ; Orgin- Tribes Andhra Pradesh' price={1205} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TJWGJWTS001847-300x300.jpg" rating={3}/>

            </div>

            <div className="home__row">
                {/*Product*/}
                <Product id="6" title='Handcrafted Multicolor Ceramic Barani ; Orgin- Tribes Rajasthan' price={650} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TPTDPTRJ00335-4-300x300.jpg" rating={4}/>
               
            </div>
            <div className="home__row">
                {/*Product*/}
                <Product id="7" title='Handcrafted Dhokra Metal Madia-Madin Couple Standing ; Orgin- Tribes Chhattisgarh' price={750} image="https://www.tribesindia.org/wp-content/uploads/2021/09/01-300x300.jpg" rating={3}/>
                <Product id="8" title='Handmade Red Jute Clutch ; Orgin- Tribes Rajasthan' price={400} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TGAUTCRJ01473-1-300x300.jpg" rating={4}/>
               
            </div>
            <div className="home__row">
                {/*Product*/}
            
                {/*Product*/}
                {/*Product*/}
            
                <Product id="9" title='Handcrafted Salfi Jhad Madia Statue ; Orgin- Tribes Chhattisgarh' price={1000} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TGADCTCG03930_Image1-1.jpg" rating={4}/>
                
                <Product id="10" title='Hand Knotted Carpet ; Orgin- Tribes Uttarakhand' price={440} image="https://www.tribesindia.org/wp-content/uploads/2021/11/1TTXHOMUT12063_1-300x300.jpg" rating={5}/>
                <Product id="11" title='Handcrafted Earring ; Orgin- Tribes Odisha' price={205} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TJWEAROR00652_Image1.JPG-300x300.jpg" rating={3}/>

            </div>
            
            
    <div className="home__row">
                <Product id="12" title='Handmade Red Jute 4 Compartment Gift Box; Orgin- Tribes Odisha' price={524} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TGAUTCRJ01481-1.jpg" rating={4}/>
                <Product id="13" title='Handcrafted Multicolor Wooden Mask ; Orgin- Tribes West Bengal' price={250} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TCBMASWB-02930.jpg" rating={3}/>
            </div>

            <div className="home__row">   
            <Product id="14" title='Tribes India Red Pink Jute Envelope Pack of 2 ; Orgin- Tribes Rajasthan' price={420} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TGAUTCRJ01460.jpg" rating={4}/>
            </div>


            <div className="home__row">   
            <Product id="15" title='Handcrafted Bell Metal Musician set ; Orgin- Tribes Chattisgarh' price={264} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TMTDCOCG08286-G.jpg" rating={3}/>
            <Product id="16" title='Handcrafted Yellow Ceramic Flower Pot ; Orgin- Tribes Rajasthan' price={220} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TPTUTIRJ00330-4.jpg" rating={5}/>
            </div>

            <div className="home__row">   
            <Product id="17" title='Cane Handled Hand Bag With Embroidery Design ; Orgin- Tribes Karnataka' price={250} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TCBDRTKA00727_IMAGE1.jpeg" rating={4}/>
            <Product id="18" title='Handcrafted Grey Metal Flower Ball Earring; Orgin- Tribes Andhra Pradesh' price={500} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TJWGJWTS001791.jpg" rating={5}/>
            <Product id="19" title='Multicolor Stole Standard Size ; Orgin- Tribes Andhra Pradesh' price={300} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TTXWOMTS34705_1.jpg" rating={4}/>
            </div>

            <div className="home__row">   
            <Product id="20" title='Palm Leaf Engraved Pattachitra Painting Depicting Tree of Life ; Orgin- New Delhi' price={470} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TPNOTPOR00694_34_IMAGE_3.jpg" rating={3}/>
            </div>


            <div className="home__row">   
            <Product id="21" title='Phank Peacock ; Orgin- Karnataka' price={640} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1smtdcoka07917-image1.jpeg.jpeg" rating={4}/>
            <Product id="22" title='Handcrafted Multicolor Ceramic Plate ; Orgin- Tribes Rajasthan' price={260} image="https://www.tribesindia.org/wp-content/uploads/2021/09/1TPTUTIRJ00283-3.jpg" rating={3}/>
            </div>



            


            


        
            </div> 
        </div>
    )
}

export default Home
