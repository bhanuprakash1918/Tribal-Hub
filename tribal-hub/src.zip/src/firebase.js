// For Firebase JS SDK v7.20.0 and later, measurementId is optional
import firebase from "firebase";
import 'firebase/auth';
import 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDa14TCVfrhN9XAbWS-IpM0askxaHwUdnY",
  authDomain: "tribal-hub-7bb88.firebaseapp.com",
  projectId: "tribal-hub-7bb88",
  storageBucket: "tribal-hub-7bb88.appspot.com",
  messagingSenderId: "656155140785",
  appId: "1:656155140785:web:b696df8ff630b429c4b890",
  measurementId: "G-VC71SX5GQ8"
};
const firebaseApp = firebase.initializeApp(firebaseConfig);

const db = firebaseApp.firestore();
const auth = firebase.auth();

export { db, auth };