import React from 'react'
import "./About.css";
import img from './img.jpg';
import img1 from './img1.png';
import img2 from './img2.png';
//import  ReactDOM  from  'react-dom';
//import {SocialMediaIconsReact} from 'social-media-icons-react';
//import { SocialIcon } from 'react-social-icons';
import { render } from "react-dom";
import SocialFlow from "./SocialFlow";

function About() {
    return (
        <div>
      <div id="slideshow">
          <figure> 
              <img src={img1} />
              <img src={img}  />
              <img src={img2} />
          </figure>
      </div>

         <div className="about_us">
              <h1>Our Vision.....</h1>
          </div>
   
   
          <div className="para">
   
   
              <p style={{fontSize: "30px"}}>  Providing our customers with handmade craft retail shopping experience is  <br/><br/>our primary idea. We work together to design,create and produce work <br/><br/>that we are proud for tribes that we believe in. We deliver our customers with handmade natural products.<br/><br/>Digitilization is the key here. Customers would be able to buy things on the go easily.<br/><br/> We are providng multiple varities of  handmade products.It is not just across India. We are expanding our <br/><br/>tribal hub facilities to some other foreign countries.  </p>
    
   
          </div>
   
     <div className="follow">
          <h3>follow us on:</h3>
     </div>

     <SocialFlow />
   
   
   
         <div className="contact">
    
   
          <h3 style={{fontcolor: 'darkblue'}}>Contact us:</h3>
    
   
          <h4 style={{fontcolor: 'black'}}> 9876532104 <br/> 040-23215542</h4>
   
   
    </div>
  
   
  
        </div>
    )
}

export default About
